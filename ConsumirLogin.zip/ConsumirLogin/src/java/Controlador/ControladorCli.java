/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Vista.Vista;
import Vista.vista2;
import cliente.WebCliente_Service;
import cliente.WebCliente;
import javax.swing.JOptionPane;

/**
 *
 * @author carlos
 */
public class ControladorCli {

    WebCliente_Service serv = new WebCliente_Service();
    WebCliente cli = serv.getWebClientePort();

    Vista vis = new Vista();
    vista2 vis2 = new vista2();

    public ControladorCli() {
        vis.setVisible(true);

    }

    public void iniciar_control() {
        vis.getBtn_ingresar().addActionListener(l -> ingrsar());
        vis.getBtn_abrirregis().addActionListener(l -> abrirdialoj());
        vis.getBtn_crearusu().addActionListener(l -> registrar());
        vis2.getBtn_registrar1().addActionListener(l -> operacion());

    }

    public void ingrsar() {

        String usu = vis.getTxt_usuario().getText();
        String pass = vis.getTxt_pass().getText();
        if (vis.getTxt_usuario().getText().isEmpty() || vis.getTxt_pass().getText().isEmpty()) {
            JOptionPane.showMessageDialog(vis, "hay campos vacios");

        } else {
            if (cli.ingresar(usu, pass) == true) {
                JOptionPane.showMessageDialog(vis, "Inicio de sesion correcto");
                abriroperacion();

            } else {
                JOptionPane.showMessageDialog(vis, "datos erronoes o el usuario no esta registrado");

            }
        }

    }

    public void registrar() {

        String usu1 = vis.getTxt_crear_usu().getText();
        String pass1 = vis.getTxt_crear_contra().getText();
        double sal1 = Double.parseDouble(vis.getTxt_saldo().getText());
        cli.crearCli(usu1, pass1, sal1);
        JOptionPane.showMessageDialog(vis, "usuario Creado Correctamente");
        vis.getDialog_registrar().dispose();

    }

    public void abrirdialoj() {
        vis.getDialog_registrar().setVisible(true);
        vis.getDialog_registrar().setSize(450, 450);
    }

    public void limpiar1() {
        vis.getTxt_usuario().setText("");
        vis.getTxt_pass().setText("");
    }

    public void limpiar2() {
        vis.getTxt_crear_usu().setText("");
        vis.getTxt_crear_contra().setText("");
        vis.getTxt_saldo().setText("");
    }

    public void abriroperacion() {

        vis2.setVisible(true);
        vis2.getLbl_nombre().setText(vis.getTxt_usuario().getText().toUpperCase());
     
    }

    public void operacion() {

        double deposito = Double.parseDouble(vis2.getTxt_valor().getText());
        double total = Double.parseDouble(vis2.getTxt_saldo().getText());
        if (vis2.getRadio_deposito().isSelected()) {
            cli.deposito(deposito, total);
            Double total2 = Double.parseDouble(vis2.getTxt_saldo().getText()) + Double.parseDouble(vis2.getTxt_valor().getText());
            vis2.getTxt_saldo().setText(total2.toString());

        } else {
            if (Double.parseDouble(vis2.getTxt_valor().getText()) > Double.parseDouble(vis2.getTxt_saldo().getText())) {
                JOptionPane.showMessageDialog(vis, "No tiene tanto dinero para retirar");

            } else {
                cli.retiro(total, deposito);
                Double total2 = Double.parseDouble(vis2.getTxt_saldo().getText()) - Double.parseDouble(vis2.getTxt_valor().getText());
                vis2.getTxt_saldo().setText(total2.toString());

            }
        }
    }
}
