/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author carlos
 */
public class Servicio_Cliente {

    public static List<Cliente> cli = new ArrayList<>();

    public Servicio_Cliente() {
    }
    
    

    public String crearCliente(String usuario, String contra1, double saldo) {

        Cliente micliente = new Cliente();
        micliente.setId(cli.size() + 1);
        micliente.setUsuario(usuario);
        micliente.setContraseña(contra1);
        micliente.setSaldo(saldo);
        cli.add(micliente);

        return "cliente agregado";
    }
}
