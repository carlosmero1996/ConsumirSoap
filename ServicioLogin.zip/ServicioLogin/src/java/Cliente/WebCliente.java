/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cliente;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import Modelo.Servicio_Cliente;

/**
 *
 * @author carlos
 */
@WebService(serviceName = "WebCliente")
public class WebCliente {

        Servicio_Cliente cs = new Servicio_Cliente();
        
          /**
     * Web service operation
     */
    @WebMethod(operationName = "CrearCli")
    public String crearCliente(@WebParam(name = "usuario") String usuario, @WebParam(name = "contrasena") String contrasena, @WebParam(name = "saldo") double saldo) {
        return cs.crearCliente(usuario, contrasena, saldo);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Ingresar")
    public boolean login(@WebParam(name = "username") String username, @WebParam(name = "password") String password) {

        boolean bandera = false;
        for (int i = 0; i < Servicio_Cliente.cli.size(); i++) {
            if (Servicio_Cliente.cli.get(i).getUsuario().equals(username) && Servicio_Cliente.cli.get(i).getContraseña().equals(password)) {
                bandera = true;
                System.out.println("inicio de sesion correcto");
            }
        }
        return bandera;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Deposito")
    public Double Deposito(@WebParam(name = "desposito") double deposito, @WebParam(name = "total") double total) {
        return total=total+deposito;
    }

     @WebMethod(operationName = "Retiro")
    public Double Retiro(@WebParam(name = "total") double total, @WebParam(name = "retiro") double retiro) {
        return total=total-retiro;
    }
    
}
